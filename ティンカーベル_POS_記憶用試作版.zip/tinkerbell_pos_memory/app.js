const STORAGE_KEY = "tinkerbell_pos_v1";

const defaultState = {
  version: 1,
  adminPin: "1234",
  seats: [
    ...Array.from({length: 6}, (_, i) => ({id:`C${i+1}`, name:`カウンター${i+1}`, customer:"", castId:"", open:true})),
    ...Array.from({length: 5}, (_, i) => ({id:`B${i+1}`, name:`ボックス${i+1}`, customer:"", castId:"", open:true}))
  ],
  casts: [
    {id:"cast1", name:"あい", hourly:2000, working:false, clockIn:null, clockOut:null},
    {id:"cast2", name:"みお", hourly:2000, working:false, clockIn:null, clockOut:null}
  ],
  menu: [
    {id:"m1", name:"キャストドリンク", price:1000, back:300},
    {id:"m2", name:"お客様ドリンク", price:800, back:0},
    {id:"m3", name:"ボトル", price:10000, back:2000},
    {id:"m4", name:"場内指名", price:2000, back:1000},
    {id:"m5", name:"延長30分", price:3000, back:0}
  ],
  orders: []
};

let state = loadState();
let currentSeatId = null;
let adminAction = null;

function loadState(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : structuredClone(defaultState);
  }catch(e){
    return structuredClone(defaultState);
  }
}
function saveState(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  renderAll();
}
const yen = n => new Intl.NumberFormat("ja-JP",{style:"currency",currency:"JPY",maximumFractionDigits:0}).format(n||0);
const nowIso = () => new Date().toISOString();
const todayKey = () => new Date().toLocaleDateString("sv-SE");

function seatOrders(seatId, includeClosed=false){
  return state.orders.filter(o => o.seatId === seatId && (includeClosed || !o.closed));
}
function seatTotal(seatId){
  return seatOrders(seatId).reduce((s,o)=>s+o.price*o.qty,0);
}
function renderAll(){
  renderFloor(); renderOrders(); renderAttendance(); renderMenu(); updateSelects();
}
function renderFloor(){
  const grid = document.getElementById("seatGrid");
  grid.innerHTML = "";
  state.seats.forEach(seat=>{
    const cast = state.casts.find(c=>c.id===seat.castId);
    const total = seatTotal(seat.id);
    const active = !!seat.customer || total>0;
    const el = document.createElement("button");
    el.className = "seat-card" + (active ? " active" : "");
    el.innerHTML = `
      <h3>${seat.name}</h3>
      <div class="customer">${seat.customer || "空席"}</div>
      <div class="muted">${cast ? "担当："+cast.name : "担当なし"}</div>
      <div class="seat-total">${yen(total)}</div>`;
    el.onclick = ()=>openSeat(seat.id);
    grid.appendChild(el);
  });
  document.getElementById("activeSeatCount").textContent = state.seats.filter(s=>s.customer || seatTotal(s.id)>0).length;
  document.getElementById("workingCastCount").textContent = state.casts.filter(c=>c.working).length;
  const sales = state.orders.filter(o=>o.closed && (o.closedAt||"").slice(0,10)===todayKey()).reduce((s,o)=>s+o.price*o.qty,0);
  document.getElementById("todaySales").textContent = yen(sales);
}
function renderOrders(){
  const wrap = document.getElementById("ordersList");
  const sorted = [...state.orders].sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  if(!sorted.length){wrap.innerHTML='<p class="muted">注文はまだねえよ。</p>';return;}
  wrap.innerHTML = sorted.map(o=>{
    const seat=state.seats.find(s=>s.id===o.seatId);
    const cast=state.casts.find(c=>c.id===o.castId);
    return `<div class="row">
      <div><strong>${o.menuName}</strong><br><span class="muted">${seat?.name||""} / ${cast?.name||"担当なし"}</span></div>
      <div>${o.qty}点</div><div>${yen(o.price*o.qty)}</div>
      <div>${o.closed ? "会計済" : "未会計"}</div>
    </div>`;
  }).join("");
}
function renderAttendance(){
  const wrap = document.getElementById("attendanceList");
  wrap.innerHTML = state.casts.map(c=>`
    <div class="row">
      <div><strong>${c.name}</strong><br><span class="muted">時給 ${yen(c.hourly)}</span></div>
      <div>${c.working ? "出勤中" : "退勤"}</div>
      <div>${c.clockIn ? new Date(c.clockIn).toLocaleTimeString("ja-JP",{hour:"2-digit",minute:"2-digit"}) : "-"}</div>
      <button onclick="toggleAttendance('${c.id}')">${c.working ? "退勤" : "出勤"}</button>
    </div>`).join("");
}
function renderMenu(){
  const wrap = document.getElementById("menuList");
  wrap.innerHTML = state.menu.map(m=>`
    <div class="row">
      <div><strong>${m.name}</strong></div><div>${yen(m.price)}</div><div>バック ${yen(m.back)}</div>
      <button class="danger" onclick="requestAdmin(()=>deleteMenu('${m.id}'))">削除</button>
    </div>`).join("");
}
function updateSelects(){
  const castOptions = `<option value="">担当なし</option>` + state.casts.map(c=>`<option value="${c.id}">${c.name}${c.working?"（出勤中）":""}</option>`).join("");
  document.getElementById("castSelect").innerHTML = castOptions;
  document.getElementById("menuSelect").innerHTML = state.menu.map(m=>`<option value="${m.id}">${m.name} ${yen(m.price)}</option>`).join("");
}
function openSeat(id){
  currentSeatId=id;
  const seat=state.seats.find(s=>s.id===id);
  document.getElementById("seatDialogTitle").textContent=seat.name;
  document.getElementById("customerName").value=seat.customer;
  updateSelects();
  document.getElementById("castSelect").value=seat.castId||"";
  renderSeatOrders();
  document.getElementById("seatDialog").showModal();
}
function renderSeatOrders(){
  const list=document.getElementById("seatOrders");
  const orders=seatOrders(currentSeatId);
  if(!orders.length){list.innerHTML='<p class="muted">この席の注文はまだねえよ。</p>';return;}
  list.innerHTML=orders.map(o=>`
    <div class="row">
      <div>${o.menuName}</div><div>${o.qty}点</div><div>${yen(o.price*o.qty)}</div>
      <button class="danger" onclick="removeOrder('${o.id}')">取消</button>
    </div>`).join("")+`<h3>合計 ${yen(seatTotal(currentSeatId))}</h3>`;
}
function saveSeat(){
  const seat=state.seats.find(s=>s.id===currentSeatId);
  seat.customer=document.getElementById("customerName").value.trim();
  seat.castId=document.getElementById("castSelect").value;
  saveState();
}
function addOrder(){
  const menu=state.menu.find(m=>m.id===document.getElementById("menuSelect").value);
  if(!menu) return;
  const qty=Math.max(1,Number(document.getElementById("orderQty").value)||1);
  const seat=state.seats.find(s=>s.id===currentSeatId);
  state.orders.push({
    id:crypto.randomUUID(), seatId:currentSeatId, customer:seat.customer,
    castId:seat.castId, menuId:menu.id, menuName:menu.name,
    price:Number(menu.price), back:Number(menu.back), qty,
    createdAt:nowIso(), closed:false, closedAt:null
  });
  saveState(); renderSeatOrders();
}
function checkout(){
  const orders=seatOrders(currentSeatId);
  if(!orders.length){alert("注文がねえよ。");return;}
  orders.forEach(o=>{o.closed=true;o.closedAt=todayKey();});
  const seat=state.seats.find(s=>s.id===currentSeatId);
  const total=orders.reduce((s,o)=>s+o.price*o.qty,0);
  alert(`会計 ${yen(total)}`);
  seat.customer="";seat.castId="";
  saveState();document.getElementById("seatDialog").close();
}
function clearSeat(){
  if(!confirm("未会計の注文も削除して席を空けます。よろしいですか？")) return;
  state.orders=state.orders.filter(o=>o.seatId!==currentSeatId || o.closed);
  const seat=state.seats.find(s=>s.id===currentSeatId);
  seat.customer="";seat.castId="";
  saveState();document.getElementById("seatDialog").close();
}
window.removeOrder=id=>{state.orders=state.orders.filter(o=>o.id!==id);saveState();renderSeatOrders();}
window.toggleAttendance=id=>{
  const c=state.casts.find(x=>x.id===id);
  if(c.working){c.working=false;c.clockOut=nowIso();}else{c.working=true;c.clockIn=nowIso();c.clockOut=null;}
  saveState();
}
function addCast(){
  const name=prompt("キャスト名");
  if(!name) return;
  const hourly=Number(prompt("時給","2000"))||0;
  state.casts.push({id:crypto.randomUUID(),name:name.trim(),hourly,working:false,clockIn:null,clockOut:null});
  saveState();
}
function addMenu(){
  const name=document.getElementById("menuName").value.trim();
  const price=Number(document.getElementById("menuPrice").value);
  const back=Number(document.getElementById("menuBack").value)||0;
  if(!name || !price){alert("商品名と価格を入れてくなんしょ。");return;}
  state.menu.push({id:crypto.randomUUID(),name,price,back});
  ["menuName","menuPrice","menuBack"].forEach(id=>document.getElementById(id).value="");
  saveState();
}
window.deleteMenu=id=>{state.menu=state.menu.filter(m=>m.id!==id);saveState();}
window.requestAdmin=fn=>{
  adminAction=fn;
  document.getElementById("pinInput").value="";
  document.getElementById("pinError").textContent="";
  document.getElementById("pinDialog").showModal();
}
function confirmPin(){
  if(document.getElementById("pinInput").value===state.adminPin){
    document.getElementById("pinDialog").close();
    const action=adminAction;adminAction=null;if(action) action();
  }else document.getElementById("pinError").textContent="PINが違います。";
}
function changePin(){
  requestAdmin(()=>{
    const newPin=document.getElementById("newPin").value.trim();
    if(newPin.length<4){alert("4桁以上にしてくなんしょ。");return;}
    state.adminPin=newPin;document.getElementById("newPin").value="";saveState();alert("PINを変更しました。");
  });
}
function backup(){
  const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);
  a.download=`tinkerbell-pos-backup-${todayKey()}.json`;a.click();URL.revokeObjectURL(a.href);
}
function restore(file){
  const reader=new FileReader();
  reader.onload=()=>{
    try{state=JSON.parse(reader.result);saveState();alert("復元しました。");}
    catch(e){alert("復元できませんでした。JSONファイルを確認してください。");}
  };
  reader.readAsText(file);
}

document.querySelectorAll(".tab").forEach(btn=>btn.onclick=()=>{
  document.querySelectorAll(".tab,.panel").forEach(el=>el.classList.remove("active"));
  btn.classList.add("active");document.getElementById(btn.dataset.tab).classList.add("active");
});
document.getElementById("saveSeatBtn").onclick=saveSeat;
document.getElementById("addOrderBtn").onclick=addOrder;
document.getElementById("checkoutBtn").onclick=checkout;
document.getElementById("clearSeatBtn").onclick=clearSeat;
document.getElementById("addCastBtn").onclick=addCast;
document.getElementById("addMenuBtn").onclick=addMenu;
document.getElementById("pinConfirmBtn").onclick=confirmPin;
document.getElementById("changePinBtn").onclick=changePin;
document.getElementById("backupBtn").onclick=backup;
document.getElementById("restoreInput").onchange=e=>e.target.files[0]&&restore(e.target.files[0]);
document.getElementById("clearClosedOrders").onclick=()=>requestAdmin(()=>{
  state.orders=state.orders.filter(o=>!o.closed);saveState();
});
document.getElementById("resetBtn").onclick=()=>requestAdmin(()=>{
  if(confirm("本当に全データを初期化しますか？")){state=structuredClone(defaultState);saveState();}
});

renderAll();
